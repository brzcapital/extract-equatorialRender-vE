export const MODEL_PREFERENCIAL = "gpt-4-turbo";
export const MODEL_FALLBACK = "gpt-5";
export const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
